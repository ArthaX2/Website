const express = require('express');
const handlebars = require('express-handlebars');

const app = express();

app.engine('handlebars', handlebars.engine());
app.set('view engine', 'handlebars');

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index', {
        title: 'Home Page',
        message: 'Welcome to Mario Kart!',
    });
});

app.get('/about', (req, res) => {
    res.render('about', {
        title: 'About Mario Kart'
    });
});

app.get('/characters', (req, res) => {
    res.render('characters', {
        title: 'Mario Kart Characters'
    });
});

app.get('/map', (req, res) => {
    res.render('map', {
        title: 'Mario Kart Map'
    });
});

app.use((req, res) => {
    res.status(404).render('404', {
        title: '404 Page Not Found'
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://127.0.0.1:${PORT}`);
});
